#welcomes the player
def welcome(name):
    print(f"Hello {name} and welcome to the World of Games (WoG).\n"\
           "Here you can find many cool games to play.")

#loads the games menu to select a game and difficulty, returns game and difficulty as a chained string
def load_game():
    game_played="0"
    game_difficulty="0"
#pick game
    while not (game_played.isdigit() and 1 <= int(game_played) <= 3):
        print("Please choose a game to play:\n"\
              "1.Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back\n"\
              "2.Guess Game - guess a number and see if you chose like the computer\n"\
              "3.Currency Roulette - try and guess the value of a random amount of USD in ILS\n")
        game_played=input()
#pick difficulty
    while not (game_difficulty.isdigit() and 1 <= int(game_difficulty) <= 5):
        game_difficulty=input("Please choose game difficulty from 1 to 5:\n")

#returns game and difficulty as a chained string
    return game_played+game_difficulty
