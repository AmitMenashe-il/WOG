from Live import load_game, welcome
#prints a welcome messege
welcome("Doron")
#prints games menu, returns game and difficulty as a chained string
game_and_difficulty=load_game()