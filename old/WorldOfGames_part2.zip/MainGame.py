from Live import load_game, welcome
#prints a welcome messege
welcome(input('Please enter your name\n'))
#prints games menu, returns game and difficulty as a chained string
load_game()